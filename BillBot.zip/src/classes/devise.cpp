#include "../../include/classes/devise.h"

using namespace cv;


/*
    CONSTRUCTEURS
*/
Devise::Devise(){
    nom = NULL;
}

Devise::Devise(String newNom){
    nom = newNom;
}


/*
    GETTERS
*/
String Devise::getNom(){

}

std::map<Devise, float> Devise::getConversions(){

}

std::vector<PieceType> Devise::getListePieceType(){

}


/*
    SETTERS
*/
void Devise::setNom(String newNom){

}

void Devise::addConversion(Devise devise, float tauxConv){

}

void Devise::removeConversion(Devise devise, float tauxConv){

}

void Devise::addPieceType(PieceType pieceType){

}

void Devise::removePieceType(PieceType pieceType){

}



