#include "../../include/classes/pieceType.h"
#include "../../include/classes/devise.h"

using namespace cv;


/*
    CONSTRUCTEURS
*/
PieceType::PieceType(){

}

PieceType::PieceType(Devise* devise, float valeur, Mat imgPieceType){

}


/*
    GETTERS
*/



/*
    SETTERS
*/




