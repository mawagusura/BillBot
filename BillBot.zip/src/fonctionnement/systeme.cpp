#include "../../include/fonctionnement/systeme.h"

using namespace cv;


/*
    GETTERS
*/

std::vector<Devise> Systeme::getListeDevises(){

    return Systeme::listeDevises;
}

std::vector<Piece> Systeme::getListePieces(){

}

std::vector<Mat> Systeme::getListeImages(){

}


/*
    SETTERS
*/
void Systeme::addDevise(Devise devise){

}

void Systeme::removeDevise(Devise devise){

}

void Systeme::addPiece(Piece piece){

}

void Systeme::removePiece(Piece piece){

}

void Systeme::addImage(Mat image){

}

void Systeme::removeImage(Mat image){

}




