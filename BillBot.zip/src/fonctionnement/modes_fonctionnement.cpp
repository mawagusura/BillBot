#include "../../include/fonctionnement/modes_fonctionnement.h"

using namespace cv;

/*
DEFINITIONS DES METHODES :
*/
