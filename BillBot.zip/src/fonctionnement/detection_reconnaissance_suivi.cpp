#include "../../include/fonctionnement/detection_reconnaissance_suivi.h"

using namespace cv;

/*
DEFINITIONS DES METHODES :
*/
