#ifndef PIECE_TYPE_H
#define PIECE_TYPE_H

#include <vector>
#include "../includesDeBase.h"
#include "piece.h"

class Devise;

class PieceType
{
    private:
    /*
        ATTRIBUTS
    */
    Devise *devise;
    float valeur;
    std::vector<Piece> listePiece;
    Mat imgPieceType;

    protected:

    public:
    /*
        CONSTRUCTEURS
    */
    PieceType();
    PieceType(Devise* devise, float valeur, Mat imgPieceType);

    /*
        GETTERS
    */
    Devise* getDevise();
    float getValeur();
    std::vector<Piece> getListePiece();
    Mat getImgPieceType();

    /*
        SETTERS
    */
    void setDevise(Devise* newDevise);
    void setValeur(float newValeur);
    void addPiece(Piece piece);
    void removePiece(Piece piece);
    void setImgPieceType(Mat image);
};

#endif // PIECE_TYPE_H

