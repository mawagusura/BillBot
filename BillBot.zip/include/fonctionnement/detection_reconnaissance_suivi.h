#ifndef DET_REC_SUIV_H
#define DET_REC_SUIV_H

#include "../includesDeBase.h"

class Partie1
{
    /*
        METHODES DE LA PARTIE 1 :

        => rajouter des ' #include "classe.h" ' avant le debut de la classe
        pour utiliser les classes definies

        => appel des methodes dans le main

        => methodes static
    */

    // ecrire les declarations des methodes ici (definitions dans le .cpp correspondant)
    // rappel les methodes sont static dans cette classe


};


#endif // DET_REC_SUIV_H
