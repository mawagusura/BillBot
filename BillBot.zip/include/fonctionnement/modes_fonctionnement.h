#ifndef DET_MOD_FONC_H
#define DET_MOD_FONC_H

#include "../includesDeBase.h"

class Partie2
{
    /*
        METHODES DE LA PARTIE 2 :

        => rajouter des ' #include "classe.h" ' avant le debut de la classe
        pour utiliser les classes definies

        => appel des methodes dans le main

        => methodes static
    */

    // ecrire les declarations des methodes ici (definitions dans le .cpp correspondant)
    // rappel les methodes sont static dans cette classe



};


#endif // DET_MOD_FONC_H

